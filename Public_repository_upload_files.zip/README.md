# Plant-based diet quality and hearing thresholds

Analysis code, study documentation and aggregate results accompanying **Plant-based diet quality and hearing thresholds in adults: Cross-sectional analyses in the United States and Korea**. The materials also document an exploratory English follow-up using self-reported hearing.

Authors: Weijun Ma, Ying Cheng, Heng Li and Hui Lv.

## Download the materials

| File | Contents |
| --- | --- |
| [Supporting Information 3](Supporting_Information_3_US_Korea_Code_and_Aggregates.zip) | US and Korean model code, score-construction modules, aggregate results and documented reconstruction boundaries |
| [Supporting Information 4](Supporting_Information_4_England_Code_and_Aggregates.zip) | Exploratory English analyses and common-age sensitivity analyses; scripts, specifications and aggregate outputs |
| [Supporting Information 5](Supporting_Information_5_Korean_Selection_Audit.zip) | Post hoc Korean selection comparison; prepared-input script and aggregate table |

These archives are byte-identical to the corresponding supporting files in the Food Science & Nutrition submission materials (v102). Checksums are in [SHA256SUMS.json](SHA256SUMS.json). Earlier journal names, version labels, table numbers and statements that an archive had not yet been deposited are historical provenance inside the preserved archives; this repository provides the current public location. No acceptance or publication by a journal is implied.

## What can be reproduced

Extract Supporting Information 3 to a new directory and run `python verify_package.py` with Python 3. This verifies archived file integrity and selected aggregate-table consistency without participant data. The archive also contains `verify_aggregate_tables.R` for additional aggregate checks.

Model and score-construction scripts require the documented prepared inputs and dependencies. These archives do **not** provide a complete, independently validated pipeline from official raw downloads. Historical source files and some extension scripts retain dependencies on the original project structure. Read each archive's README and, in Supporting Information 3, `documentation/REBUILD_BOUNDARIES.md` before execution. Aggregate outputs are not sufficient to refit participant-level survey models.

US and Korean score definitions differ; their coefficients are not pooled. The English extension is exploratory, uses a different outcome and is not external validation of the audiometric findings. Cross-sectional associations do not establish causation.

## Source data and access restrictions

No participant-level source or derived datasets, participant identifiers, food-record ledgers or fitted-model objects are distributed here. Source data must be obtained from their providers under the applicable terms:

- NHANES: https://wwwn.cdc.gov/nchs/nhanes/
- USDA Food Patterns Equivalents Database: https://www.ars.usda.gov/northeast-area/beltsville-md-bhnrc/beltsville-human-nutrition-research-center/food-surveys-research-group/docs/fped-databases/
- KNHANES: https://knhanes.kdca.go.kr/knhanes/main.do
- ELSA: UK Data Service study 5050, as specified in the English archive; access is subject to the End User Licence and any additional conditions.

This repository does not grant access to restricted data or permission to redistribute provider data. No blanket reuse license has been assigned to this deposit; applicable third-party rights and notices remain in force. Contact the authors about reuse not otherwise permitted. Do not upload locally generated participant-level outputs to this repository.

## Version and citation

Initial public deposit: 17 November 2026, supporting-files version v102. Use GitHub's commit permalink to identify the exact deposited version. This GitHub repository has no assigned DOI and is not described as a DOI-bearing archival deposit.

Suggested citation: Ma W, Cheng Y, Li H, Lv H. Plant-based diet quality and hearing thresholds: analysis code and aggregate results. GitHub repository, 2026. https://github.com/weijunma03/plant-based-diet-hearing (cite the commit and access date used).
